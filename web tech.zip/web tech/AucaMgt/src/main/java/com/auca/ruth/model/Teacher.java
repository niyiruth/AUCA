package com.auca.ruth.model;

import java.util.UUID;

import jakarta.persistence.*;

@Entity
@Table(name = "teacher")
public class Teacher {
	@Id
	@GeneratedValue
	private UUID teacher_id;
	private String first_name;
	private String last_name;
	@Enumerated(EnumType.STRING)
	private EnumTeacher  qualification;
	@OneToOne
	@JoinColumn(name = "course_id")
	private Course course;
	
	public Teacher() {
		super();
	}

	public Teacher(UUID teacher_id) {
		super();
		this.teacher_id = teacher_id;
	}

	public Teacher(String first_name, String last_name, EnumTeacher  qualification, Course course) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.qualification = qualification;
		this.course = course;
	}

	public UUID getTeacher_id() {
		return teacher_id;
	}

	public void setTeacher_id(UUID teacher_id) {
		this.teacher_id = teacher_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public EnumTeacher getQualification() {
		return qualification;
	}

	public void setQualification(EnumTeacher qualification) {
		this.qualification = qualification;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}
	
	
	
}

