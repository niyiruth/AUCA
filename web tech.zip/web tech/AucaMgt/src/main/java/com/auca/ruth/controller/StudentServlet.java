package com.auca.ruth.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.auca.ruth.dao.StudentDao;
import com.auca.ruth.model.Student;



/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	Student student = new Student();
	StudentDao dao = new StudentDao();

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String SubmitMethod = req.getParameter("Action");
		if (SubmitMethod.equals("create")) {			
			register(req, res);
		}else if(SubmitMethod.equals("update")) {
			modify(req, res);
		}else if(SubmitMethod.equals("delete")) {
			remove(req, res);
		}
		

	}

	protected void register(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String FirstName = req.getParameter("first_name");
		String LastName = req.getParameter("last_name");
		String DateOfBirth = req.getParameter("date_of_birth");
		
		if(FirstName.isEmpty() || LastName.isEmpty() || DateOfBirth.isEmpty()) {
			
			req.getRequestDispatcher("/Student.jsp").forward(req, res);
		}else {
			student.setDate_of_birth(DateOfBirth);
			student.setFirst_name(FirstName);
			student.setLast_name(LastName);

			 dao.register(student);
			
			req.getRequestDispatcher("/Student.jsp").forward(req, res);
		}

		
	}

	protected void modify(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

	    String studentIdString = req.getParameter("Student_id");
	    if (studentIdString == null || studentIdString.isEmpty()) {
	        
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);
	        return;
	    }

	    try {        
	       
	    	int StuId = Integer.parseInt(studentIdString);
	        String firstName = req.getParameter("first_name");
	        String lastName = req.getParameter("last_name");
	        String dateOfBirth = req.getParameter("date_of_birth");
	        
	        if (firstName.isEmpty() || lastName.isEmpty() || dateOfBirth.isEmpty()) {
	            req.setAttribute("message", "Please fill in all fields");
	            req.getRequestDispatcher("/Student.jsp").forward(req, res);
	            return;
	        }
	        
	        // Assuming  student is declared and initialized somewhere in your code
	        student.setStudent_id(StuId);
	        student.setDate_of_birth(dateOfBirth);
	        student.setFirst_name(firstName);
	        student.setLast_name(lastName);

	        
	         dao.edit(student);
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);                
	    } catch (IllegalArgumentException e) {
	        // Handle invalid UUID string	       
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);
	    }

	}

	protected void remove(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

	    String studentIdString = req.getParameter("Student_id");
	    if (studentIdString == null || studentIdString.isEmpty()) {
	        req.setAttribute("message", "Student Id is missing");
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);
	        return;
	    }

	    try {
	        // Convert the ID string to a ID object
	        int studentId = Integer.parseInt(studentIdString);
	        // No need to check if studentId is null after UUID.fromString()

	        // Assuming stu is declared and initialized somewhere in your code
	        student.setStudent_id(studentId); 
	        dao.remove(student);
	       
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);  

	    } catch (IllegalArgumentException e) {
	        // Handle invalid UUID string
	        req.setAttribute("message", "Invalid Student Id format");
	        req.getRequestDispatcher("/Student.jsp").forward(req, res);
	    }

	}
	
	
	
}
