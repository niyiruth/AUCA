package com.auca.ruth.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auca.ruth.dao.UserDao;
import com.auca.ruth.model.Users;



/**
 * Servlet implementation class AucaUser
 */
@WebServlet("/AucaUser")
public class AucaUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AucaUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String Action = req.getParameter("submitAction");
		if(Action.equals("create")) {
			register(req, res);
		}else if(Action.equals("login")) {
			login(req, res);
		}
	}
	
	protected void register(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String name = req.getParameter("name");
		String Email = req.getParameter("email");
		String Password = req.getParameter("password");
		String ConPass = req.getParameter("conpassword");
		String Role = req.getParameter("origin");
		
		if(name.isEmpty() || Email.isBlank() || Password.isEmpty() || ConPass.isEmpty() ) {
			
			req.getRequestDispatcher("/signup.jsp").forward(req, res);
			return;
		}
		
		if (!Password.equals(ConPass)) {
		    
		    req.getRequestDispatcher("/signup.jsp").forward(req, res);
		    return;
		}
		
		Users au = new Users();
		au.setEmail(Email);
		au.setPassword(Password);
		au.setRole(Role);
		
		UserDao dao = new UserDao();
	
		Users use = dao.Register(au);
		if(use != null) {
			req.getRequestDispatcher("/signup.jsp").forward(req, res);
		}
		
		
		
	}
	
	
	protected void login(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String Email = req.getParameter("email");
		String Password = req.getParameter("password");
		
		String Role = req.getParameter("origin");
		
		if( Email.isBlank() || Password.isEmpty() ) {
			
			req.getRequestDispatcher("/Login.jsp").forward(req, res);
			return;
		}
		
		
		Users au = new Users();
		au.setEmail(Email);
		au.setPassword(Password);
		au.setRole(Role);
		
		UserDao dao = new UserDao();
	
		Users validate = dao.login(Email, Password);
		//session
		if(validate != null) {
			HttpSession sess = req.getSession();
			sess.setAttribute("Password", Password);
			sess.setAttribute("Email", Email);
			sess.setAttribute("Role", Role);
			sess.setMaxInactiveInterval(1 * 60);
			 String redirectScript = "<script>setTimeout(function() { window.location.href = 'Login.jsp'; }, 60000);</script>";
		        res.getWriter().println(redirectScript);
			req.getRequestDispatcher("index.jsp").forward(req, res);
		}else {
			
			req.getRequestDispatcher("Login.jsp").forward(req, res);
		}
		
		
		
		
	}
}
