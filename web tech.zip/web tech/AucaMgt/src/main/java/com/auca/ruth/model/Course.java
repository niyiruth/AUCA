package com.auca.ruth.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.*;
@Entity
@Table(name = "course")
public class Course {

	@Id
	@GeneratedValue
	private UUID course_id;
	@Column(name = "course_code")
	private String course_code;
	@Column(name = "course_name")
	private String course__name;
	@OneToOne(mappedBy = "course")
	private Course_Definition Deff;
	@OneToOne(mappedBy = "course")
	private Teacher teacher;
	@ManyToOne
	@JoinColumn(name = "semester_id")
	private Semester seme;
	@ManyToOne
	@JoinColumn(name = "department_id")
	private Academic_unit department;
	
	@ManyToMany(mappedBy = "course")
    private List<StudentRegistration> studentReg = new ArrayList<StudentRegistration>();

	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Course(UUID course_id) {
		super();
		this.course_id = course_id;
	}

	public Course(String course_code, String course__name, Course_Definition Deff, Teacher teacher, Semester seme,
			Academic_unit department, List<StudentRegistration> studentReg) {
		super();
		this.course_code = course_code;
		this.course__name = course__name;
		this.Deff = Deff;
		this.teacher = teacher;
		this.seme = seme;
		this.department = department;
		this.studentReg = studentReg;
	}

	public UUID getCourse_id() {
		return course_id;
	}

	public void setCourse_id(UUID course_id) {
		this.course_id = course_id;
	}

	public String getCourse_code() {
		return course_code;
	}

	public void setCourse_code(String course_code) {
		this.course_code = course_code;
	}

	public String getCourse__name() {
		return course__name;
	}

	public void setCourse__name(String course__name) {
		this.course__name = course__name;
	}

	public Course_Definition getCouDef() {
		return Deff;
	}

	public void setCouDef(Course_Definition Deff) {
		this.Deff = Deff;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public Semester getSeme() {
		return seme;
	}

	public void setSeme(Semester seme) {
		this.seme = seme;
	}

	public Academic_unit getDepartment() {
		return department;
	}

	public void setDepartment(Academic_unit department) {
		this.department = department;
	}

	public List<StudentRegistration> getStudentReg() {
		return studentReg;
	}

	public void setStudentReg(List<StudentRegistration> studentReg) {
		this.studentReg = studentReg;
	}
	
	
	
}
