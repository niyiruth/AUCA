package com.auca.ruth.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.auca.ruth.model.Student;
import com.auca.ruth.util.HibernateUtil;

public class StudentDao {
	public Student register (Student stu) {
		Transaction tr = null;
		try (Session ss = HibernateUtil.getSessionFactory().openSession()){
			tr = ss.beginTransaction();
			ss.save(stu);
			tr.commit();
			return stu;			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Student edit (Student stu) {
		Transaction tr = null;
		try (Session ss = HibernateUtil.getSessionFactory().openSession()){
			tr = ss.beginTransaction();
			ss.update(stu);
			tr.commit();
			return stu;			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public Student remove (Student stu) {
		Transaction tr = null;
		try (Session ss = HibernateUtil.getSessionFactory().openSession()){
			tr = ss.beginTransaction();
			ss.delete(stu);
			tr.commit();
			return stu;			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
