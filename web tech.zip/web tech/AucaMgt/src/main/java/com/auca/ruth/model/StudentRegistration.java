package com.auca.ruth.model;


import java.time.LocalDateTime;
import java.util.ArrayList;

import java.util.List;
import java.util.UUID;

import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.*;
@Entity
public class StudentRegistration {
	@Id
	@GeneratedValue
	private UUID registration_id;
	@Column(name = "registration_code")
	private String registration_code;
	@UpdateTimestamp
    private LocalDateTime registration_date;
	@ManyToOne
	@JoinColumn(name = "student_id")
	private Student student;
	@ManyToOne
	@JoinColumn(name = "semester_id")
	private Semester sem;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "studentReg_course",joinColumns = @JoinColumn(name="registration_id")
	,inverseJoinColumns =@JoinColumn(name="course_id"))
	private List<Course>course=new ArrayList<Course>();
	@ManyToOne
	@JoinColumn(name = "department_id")
	private Academic_unit department;
	
	public StudentRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentRegistration(UUID registration_id) {
		super();
		this.registration_id = registration_id;
	}

	

	public StudentRegistration(String registration_code,  Student student, Semester sem,
			List<Course> course, Academic_unit department) {
		super();
		this.registration_code = registration_code;
		
		this.student = student;
		this.sem = sem;
		this.course = course;
		this.department = department;
	}

	public UUID getRegistration_id() {
		return registration_id;
	}

	public void setRegistration_id(UUID registration_id) {
		this.registration_id = registration_id;
	}

	public String getRegistration_code() {
		return registration_code;
	}

	public void setRegistration_code(String registration_code) {
		this.registration_code = registration_code;
	}	
	


	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Semester getSem() {
		return sem;
	}

	public void setSem(Semester sem) {
		this.sem = sem;
	}

	public List<Course> getCourse() {
		return course;
	}

	public void setCourse(List<Course> course) {
		this.course = course;
	}

	public Academic_unit getDepartment() {
		return department;
	}

	public void setDepartment(Academic_unit department) {
		this.department = department;
	}
	
	
	
}

