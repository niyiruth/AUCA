package com.auca.ruth.model;

import java.util.List;
import java.util.UUID;

import jakarta.persistence.*;

@Entity
@Table(name = "students")
public class Student {
	@Id
	@GeneratedValue
	private int student_id;	
	private String first_name;
	private String last_name;
	private String date_of_birth;
	@OneToMany(mappedBy = "student")	
	private List<StudentRegistration> registration;
	
	public Student() {
		super();
	}

	public Student(int student_id) {
		super();
		this.student_id = student_id;
	}

	public Student(String first_name, String last_name, String date_of_birth, List<StudentRegistration> registration) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.date_of_birth = date_of_birth;
		this.registration = registration;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public List<StudentRegistration> getRegistration() {
		return registration;
	}

	public void setRegistration(List<StudentRegistration> registration) {
		this.registration = registration;
	}
	
	
}

