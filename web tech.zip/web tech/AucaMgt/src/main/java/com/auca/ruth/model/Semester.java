package com.auca.ruth.model;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.*;
@Entity
@Table(name = "semester")
public class Semester {
	@Id
	@GeneratedValue
	private UUID semester_id;
	private String semester_name;
	private LocalDate starting_date;
	private LocalDate end_date;
	@OneToMany(mappedBy = "sem")
	private List<StudentRegistration> registration;
	@OneToMany(mappedBy = "seme")
	private List<Course> course;
	
	public Semester() {
		super();
		
	}

	public Semester(UUID semester_id) {
		super();
		this.semester_id = semester_id;
	}

	public Semester(String semester_name, LocalDate starting_date, LocalDate end_date,
			List<StudentRegistration> registration, List<Course> course) {
		super();
		this.semester_name = semester_name;
		this.starting_date = starting_date;
		this.end_date = end_date;
		this.registration = registration;
		this.course = course;
	}

	public UUID getSemester_id() {
		return semester_id;
	}

	public void setSemester_id(UUID semester_id) {
		this.semester_id = semester_id;
	}

	public String getSemester_name() {
		return semester_name;
	}

	public void setSemester_name(String semester_name) {
		this.semester_name = semester_name;
	}

	public LocalDate getStarting_date() {
		return starting_date;
	}

	public void setStarting_date(LocalDate starting_date) {
		this.starting_date = starting_date;
	}

	public LocalDate getEnd_date() {
		return end_date;
	}

	public void setEnd_date(LocalDate end_date) {
		this.end_date = end_date;
	}

	public List<StudentRegistration> getRegistration() {
		return registration;
	}

	public void setRegistration(List<StudentRegistration> registration) {
		this.registration = registration;
	}

	public List<Course> getCourse() {
		return course;
	}

	public void setCourse(List<Course> course) {
		this.course = course;
	}
	
	
	
}

