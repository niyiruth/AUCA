package com.auca.ruth.model;

public enum EnumTeacher {
	PHD,
	MASTERS,
	PROFESSOR;
}
