package com.auca.ruth.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import jakarta.persistence.*;

@Entity
@Table(name = "academic_unit")
public class Academic_unit {
	@Id
	@GeneratedValue
	private UUID academic_id;
	private String academic_code;
	private String academic_name;
	@Enumerated(EnumType.STRING)
	@Column(name = "type")
	private EnumAcademic_unit type;
	
	@ManyToOne
    @JoinColumn(name = "parent_id")
    private Academic_unit parent;
    
    @OneToMany(mappedBy = "parent")
    private List<Academic_unit> children = new ArrayList<>();
	
	public Academic_unit() {
		
	}

	public Academic_unit(UUID academic_id) {
		super();
		this.academic_id = academic_id;
	}

	public Academic_unit(String academic_code, String academic_name, EnumAcademic_unit type, Academic_unit parent,
			List<Academic_unit> children) {
		super();
		this.academic_code = academic_code;
		this.academic_name = academic_name;
		this.type = type;
		this.parent = parent;
		this.children = children;
	}

	public UUID getAcademic_id() {
		return academic_id;
	}

	public void setAcademic_id(UUID academic_id) {
		this.academic_id = academic_id;
	}

	public String getAcademic_code() {
		return academic_code;
	}

	public void setAcademic_code(String academic_code) {
		this.academic_code = academic_code;
	}

	public String getAcademic_name() {
		return academic_name;
	}

	public void setAcademic_name(String academic_name) {
		this.academic_name = academic_name;
	}

	public EnumAcademic_unit getType() {
		return type;
	}

	public void setType(EnumAcademic_unit type) {
		this.type = type;
	}

	public Academic_unit getParent() {
		return parent;
	}

	public void setParent(Academic_unit parent) {
		this.parent = parent;
	}

	public List<Academic_unit> getChildren() {
		return children;
	}

	public void setChildren(List<Academic_unit> children) {
		this.children = children;
	}

	
	
		
}

