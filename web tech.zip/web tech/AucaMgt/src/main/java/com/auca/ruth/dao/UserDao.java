package com.auca.ruth.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.auca.ruth.model.Users;
import com.auca.ruth.util.HibernateUtil;

import java.sql.*;

public class UserDao {
	
	public Users Register(Users au) {
		Transaction tr = null;
		try(Session ss = HibernateUtil.getSessionFactory().openSession()) {
			tr = ss.beginTransaction();
			ss.save(au);
			tr.commit();
			return au;
		} catch (Exception e) {
			if(tr != null) {
				tr.rollback();
			}
			return null;
		}
	}
	


	public Users login(String email, String password) {
		try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/webtech", "root", "");
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email = ? AND password = ?");
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Users user = new Users();                	
                // You may set other user attributes here if needed
                return user;
            } else {
                return null; // User not found with the provided credentials
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Error occurred during login
        }
	}
}
