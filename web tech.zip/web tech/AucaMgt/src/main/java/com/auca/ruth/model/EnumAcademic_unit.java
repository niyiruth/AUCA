package com.auca.ruth.model;

public enum EnumAcademic_unit {
	PROGRAM,
	FACULTY,
	DEPARTMENT;
}
